#!/bin/sh
set -eu

if [ "$(id -u)" -ne 0 ]; then
  echo "Run this installer as root." >&2
  exit 1
fi

install -m 0755 saasolution-drive-edge /usr/local/bin/saasolution-drive-edge
install -m 0755 saasolution-drive-edge-enroll /usr/local/bin/saasolution-drive-edge-enroll
install -m 0755 saasolution-drive-edge-beta-setup /usr/local/bin/saasolution-drive-edge-beta-setup

if ! getent group saasolution-edge >/dev/null 2>&1; then
  groupadd --system saasolution-edge
fi
if ! id -u saasolution-edge >/dev/null 2>&1; then
  useradd --system --gid saasolution-edge --home-dir /var/lib/saasolution-drive-edge \
    --shell /usr/sbin/nologin saasolution-edge
fi

install -d -m 0750 -o saasolution-edge -g saasolution-edge /var/lib/saasolution-drive-edge
install -m 0644 saasolution-drive-edge.service /etc/systemd/system/saasolution-drive-edge.service

echo "Binaries installed. Complete the beta setup before enabling the service."
echo "Read BETA_PROGRAM.md and INSTALLATION.md, then run saasolution-drive-edge-beta-setup."
echo "The setup command creates /etc/saasolution-drive-edge; do not create it first."
