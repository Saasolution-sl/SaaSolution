# SaaSolution Drive Edge limited beta

Version `0.2.0-beta.1` is a controlled technical beta for selected organizations. It is not a
general-availability storage product and is not sold as an immutable backup.

## Free beta offer

- Each accepted organization receives a 30-day guided beta cohort.
- No payment method is required and there is no automatic charge at the end.
- Continued use after the cohort requires a separate written agreement or a later public plan.
- Local customer files are never deleted automatically when a cohort ends. Offboarding must revoke
  the node credentials and preserve or export the local operational copy.

## Supported beta targets

- Generic 64-bit Linux on x86-64.
- Generic 64-bit Linux on ARM64.
- Raspberry Pi OS 64-bit on ARM64 using reliable external storage.

Docker, TrueNAS, Unraid, Synology, QNAP and Windows Server remain evaluation targets until their
clean-install and recovery matrices are completed. The supplied container and service examples are
useful for supervised testing but are not vendor-certified packages.

## Participation requirements

1. Use a dedicated test share or data that has an independently verified backup.
2. Do not make Edge the only copy of business-critical files.
3. Use a dedicated versioned Cubbit DS3 bucket and node-specific credentials.
4. Nominate one technical contact who can provide logs with secrets and filenames removed.
5. Accept that support is best-effort during the beta and no uptime or recovery SLA is offered.
6. Report suspected data loss or credential exposure immediately and stop affected nodes.

## Onboarding

SaaSolution supplies a beta node ID, tenant ID and scoped storage details after accepting an
organization. The beta setup tool creates a protected management token and encryption key locally,
copies the scoped S3 credential into platform-protected storage and refuses to overwrite an existing
installation.

The acceptance flag records that the operator has read this document; it is not a billing or licence
enforcement mechanism. Run `sh install-beta.sh` from the extracted archive first. The installer
creates the locked-down service account and runtime directory, but deliberately leaves the
configuration directory absent so the setup tool can create it safely:

```sh
saasolution-drive-edge-beta-setup \
  -accept-beta-terms \
  -output /etc/saasolution-drive-edge \
  -data-directory /var/lib/saasolution-drive-edge \
  -share-root /srv/saasolution-drive/documents \
  -node-id NODE_ID_FROM_SAASOLUTION \
  -tenant-id TENANT_ID_FROM_SAASOLUTION \
  -endpoint https://YOUR-CUBBIT-DS3-ENDPOINT \
  -bucket YOUR_VERSIONED_BUCKET \
  -credentials-file /root/edge-beta-s3-credentials.json
```

Never put an access key, secret key, vault key or management token in a command argument.

After setup, give the service account ownership of the protected configuration, confirm it can read
the test share, and then start the service:

```sh
chown -R saasolution-edge:saasolution-edge /etc/saasolution-drive-edge
# Grant saasolution-edge read/write access to /srv/saasolution-drive/documents using your normal ACL policy.
systemctl daemon-reload
systemctl enable --now saasolution-drive-edge
systemctl status --no-pager saasolution-drive-edge
```

## Release verification

Every beta archive is listed in `SHA256SUMS`. The checksum list is signed with the SaaSolution Edge
Ed25519 release key and published with `SHA256SUMS.sig` and `RELEASE-PUBLIC-KEY.txt`. Verify both the
signature and the archive checksum before installing.
