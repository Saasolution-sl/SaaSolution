# Edge installation guide

Status: packaging examples are implemented; vendor UI steps require validation on each target model
and OS release before production support is claimed.

## Enrollment without shell-history secrets

Create an Edge installation in the SaaSolution administration service, then pipe the short-lived
one-time code to the enrollment CLI. Do not put it in a command argument:

```sh
read -rs PAIRING_CODE
printf '%s\n' "$PAIRING_CODE" | saasolution-drive-edge-enroll \
  -management-url https://management.example.invalid \
  -node-name "Amsterdam office" -pairing-code-file - \
  -output /var/lib/saasolution-drive-edge-install
unset PAIRING_CODE
```

The CLI prints only the generated configuration path. It refuses to overwrite existing secret
files. The backend contract consumes the pairing code atomically and returns a node-specific,
tenant/folder-scoped credential envelope. The example URL must be replaced by the deployed
SaaSolution management host.

Edit only the share roots/include/exclude policy after enrollment. Never copy credentials from one
node to another. Ensure the configured bucket has versioning enabled. Object Lock is not enabled by
the agent.

## Docker Compose (generic Linux, x86-64 or ARM64)

1. Copy `.env.example` to `.env` and use absolute host paths. Keep `.env` free of secret values; it
   contains only paths and runtime IDs.
2. Make the data/share paths writable by `EDGE_UID:EDGE_GID`. Make each bind-mounted secret a regular
   non-symlink file owned/readable only by that identity (mode `0400` or `0600`); Compose file-backed
   secret mode/ownership is not relied upon.
3. Ensure `edge.json` uses container paths: `/var/lib/saasolution-drive-edge`,
   `/srv/saasolution-drive/...`, and `/run/secrets/edge_*`.
4. Run `docker compose config` and inspect mounts, then `docker compose up -d`.
5. Check `docker compose ps`, the JSON logs, and `http://127.0.0.1:8090/readyz`.

The container is non-root, drops all capabilities, uses a read-only root filesystem and does not run
Samba/NFS. Configure the host's native SMB/NFS service against the synchronized host path.

## Raspberry Pi OS 64-bit

Use a 64-bit ARM64 Raspberry Pi OS release and the same Compose path. Put the data directory and
working share on storage sized for the operational copy plus unsynchronized/version staging; avoid
using a small boot SD card for customer data. Set a meaningful reserve and validate sustained disk
and network throughput before production use.

## TrueNAS SCALE

Use the supported custom application/Compose facility for the installed TrueNAS SCALE release.
Create dedicated host datasets for agent state and the synchronized share, map them to the container
paths above, run as a non-root UID/GID with dataset ACL access, and use host networking. Keep SMB/NFS
configured in TrueNAS; do not add Samba/NFS to the Edge container. Snapshot the state dataset, but do
not restore an old database over a running agent.

## Unraid

Import `packaging/unraid/saasolution-drive-edge.xml` or reproduce its three path mappings. Store state
under appdata and the operational copy under a user share. Configure Unraid SMB/NFS for the user
share. Add the three secret files as read-only file mounts if the UI does not expose Compose secrets.
Do not enable Privileged mode.

## Synology DSM Container Manager

On a model that supports Container Manager, create a project from the Compose file. Map one folder
for state and one shared folder for the operational copy, use host networking where supported, and
run with a dedicated non-admin UID/GID that has only those folder permissions. Continue using DSM's
File Services for SMB/NFS. Native SPK packaging is a future wrapper around the same agent binary.

## QNAP Container Station

Create an application from the Compose file, bind a dedicated Container Station data folder and the
chosen QTS shared folder, use host networking, and run non-root. Continue using QTS Control Panel for
SMB/NFS. Native QPKG packaging is a future wrapper around the same agent binary.

## Linux systemd

Install the matching signed binary as `/usr/local/bin/saasolution-drive-edge`, create a locked
`saasolution-edge` service account, place configuration/secrets under `/etc/saasolution-drive-edge`,
and state under `/var/lib/saasolution-drive-edge`. Adapt `ReadWritePaths` in the supplied unit for
every configured share, then run `systemd-analyze security saasolution-drive-edge.service`, enable
and start it. Do not grant the service login, sudo or broad filesystem access.

## Windows Server

The Go agent compiles for Windows x86-64 and can run interactively for compatibility testing with
NTFS local roots. Enrollment protects secret files with DPAPI for the Windows identity that runs the
enrollment command. The current artifact is not yet a native Windows Service and does not claim
production unattended Windows Server support. A signed service host must enroll as its dedicated
service identity; installer/uninstaller, ACL, long-path and service recovery testing remain gates.
