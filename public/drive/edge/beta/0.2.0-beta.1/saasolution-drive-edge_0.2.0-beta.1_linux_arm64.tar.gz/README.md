# SaaSolution Drive Edge

Current release: **0.2.0-beta.1**, a limited 30-day guided beta for selected Linux x86-64 and ARM64
installations. Read `docs/BETA_PROGRAM.md` before onboarding a node. Beta participants must retain an
independent backup and must not use Edge as the only copy of business-critical data.

SaaSolution Drive Edge is the additive, offline-first synchronization service for NAS, server,
mini-PC and Raspberry Pi installations. Each location works against its local filesystem at LAN
speed. The agent records mutations durably and performs **near-real-time synchronization** through a
versioned Cubbit DS3 bucket whenever connectivity is available.

The Go service does not replace the Android client, Windows snapshot backup, subscriptions, or the
NAS operating system's SMB/NFS server. It adds a separate multi-writer synchronization protocol.

## Implemented agent capabilities

- Recursive watchers plus periodic full reconciliation, multiple shares, include/exclude rules,
  symlink policy, NFC Unicode identity, case-collision detection, stable IDs and rename evidence.
- SQLite WAL metadata and a FULL-synchronous, idempotent mutation journal with explicit tombstones,
  restart recovery, vector revisions and safe ordering utilities.
- HTTPS-only S3 adapter for custom Cubbit endpoints, optional private CA, versioning/Object Lock
  inspection, checksums, immutable objects/events, resumable multipart uploads, retry with jitter,
  concurrency, bandwidth caps and quiet hours.
- AES-256-GCM chunk encryption, randomized nonces, authenticated metadata, HMAC-derived opaque
  object names and no remote plaintext filenames or content.
- Atomic verified downloads, reserve-space checks, staged immutable local revisions, guarded deletes
  and preservation of unscanned local edits.
- Deterministic split-brain handling: non-conflicting convergence, edit/delete and rename/edit
  conflicts, binary preservation, conservative common-base text merges and reversible restore.
- Loopback health/status/metrics endpoints and bearer-authenticated management API plus embedded
  node console at `http://127.0.0.1:8090/admin/`.
- TLS one-time enrollment client, strict envelopes, exclusive provisioning, owner-only Unix secrets
  and current-identity Windows DPAPI protection.
- Abnormal mass-change publication pause and channel-scoped Ed25519-signed update metadata checks.
- Non-root multi-stage container, Compose, systemd and Unraid examples, vendor deployment guidance,
  multi-architecture verification and signed beta archive tooling.

## Local development

Go 1.27 is the release toolchain.

```powershell
cd C:\Users\othma\Documents\ChatGPT\saasolution-drive-edge
go test ./...
go vet ./...
go run ./cmd/saasolution-drive-edge -config C:\absolute\path\edge.json
```

Copy `edge.example.json` to an ignored local path and replace every placeholder. Secret values belong
in the referenced secret files, never in the JSON. Cubbit synchronization requires an existing
tenant-scoped bucket with versioning enabled; the agent never creates a production bucket or enables
Object Lock.

Use `docs/TESTING.md` for the disposable TLS S3/fault environment. Packaging and clean-install paths
are in `docs/INSTALLATION.md`; recovery and troubleshooting are in `docs/OPERATIONS.md`.

## Honest production boundary

The repository contains no deployed SaaSolution identity/backend runtime and no administration web
source. Consequently, fleet overview, server-enforced tenant authorization, credential brokerage and
rotation, revocation propagation, online advisory locks, remote commands/alerts and the full SaaS
dashboard remain integration gates. The local console manages one enrolled node only.

The cryptographic wire format has strong implemented primitives and tamper tests but still requires
an independent format review, recovery/key-rotation design and compatibility decision with the
existing Android/Windows draft formats before a production interoperability claim. See
`docs/PRODUCTION_GATES.md`; do not market this repository snapshot as a completed production launch.
