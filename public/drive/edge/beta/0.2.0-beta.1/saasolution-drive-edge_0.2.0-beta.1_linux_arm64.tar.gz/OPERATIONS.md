# Edge operations, upgrade, uninstall and recovery

## Upgrade

1. Confirm the current node is not in an active transfer or conflict-resolution action.
2. Back up the agent state directory and record the current signed artifact version.
3. Verify the new artifact signature, checksum and SBOM from the release channel.
4. Pull/install one allowed semantic version, stop the old process gracefully, and start the new one.
5. Confirm `/readyz`, SQLite quick-check, node heartbeat, bucket versioning and queued-operation
   progress. Roll back the binary/image—not the database—unless the release notes explicitly confirm
   a reversible schema migration.

When enabled, the agent periodically checks channel-scoped update metadata and accepts it only after
Ed25519 signature verification. It reports availability but never installs automatically. Verify the
artifact SHA-256, release signature and SBOM, then use the controlled procedure above. Enabling the
checker requires the release service URL and offline-signing public key.

## Uninstall (preserve data by default)

Pause publication, stop and remove only the service/container, and retain both the operational share
and agent state directory. Removing state destroys local journals, conflict versions and enrollment
identity. Delete state only after explicit data-owner approval and a verified export/retention check.

## Recovery and re-enrollment

- Restore the operational filesystem independently of the agent.
- If intact, restore the matching state directory while the agent is stopped, then run a full
  reconciliation before resuming publication.
- If node credentials are compromised, revoke the node in SaaSolution first. Create a new
  installation/pairing code and enroll into a new empty state directory. Never reuse another node's
  credentials or copy an old SQLite database into the new identity.
- Keep the old state read-only until queued changes and conflicts are accounted for.

## Troubleshooting

- `invalid_config`: validate absolute, non-overlapping paths and loopback listener.
- `credential_invalid`: re-enroll or rotate the affected node; do not paste keys into logs/tickets.
- `credential_underprivileged`: verify assigned tenant/bucket/prefix policy in the backend broker.
- `bucket_validation_failed`: endpoint/bucket is unreachable or versioning is not enabled.
- `remote_unavailable`: local access continues; inspect network/DNS/TLS and allow queued retries.
- `case_collision`: rename one path through conflict resolution before materialization.
- `mass_change_pause`: investigate ransomware or bulk maintenance, verify versions, then use the
  authenticated `POST /v1/sync/resume` endpoint.
- low disk: free space outside Edge, increase capacity or adjust selective sync; do not delete the
  SQLite WAL or staging files manually.

Diagnostic bundles must be built from allow-listed status, safe error codes, metrics and redacted
logs. Never attach configuration secrets, SQLite content, filenames or customer files by default.
